package sample1;

import java.util.Vector;

public class Spiel {

  private final Integer maxSpieler = 12;

  private static Spiel instance = new Spiel();

  private Vector<Spieler>  mySpieler = new Vector<Spieler>();

  private Spiel() {
  }

  public static Spiel getInstance() {

    return instance;
  }

  public void addSpieler(Spieler spieler) {
      this.mySpieler.add(spieler);
  }

  public void startSpiel() {

      for (Spieler spieler: mySpieler) {
          ((Thread)spieler).start();
      }
  }

  public void setMaxSpieler(int anzahl) {
  }

  public int getMaxSpieler() {

      return maxSpieler;
  }

  public void clear(){
      this.mySpieler = new Vector<Spieler>();
  }

}